/* ========================================== 
MENU RESPONSIVE
========================================== */
$(function () {
  const header = $("header").outerHeight();
  // console.log(header);
  const burgerMenu = document.getElementById("burger");
  const navbarMenu = document.getElementById("menu-nav");

  // Show and Hide Navbar Menu
  burgerMenu.addEventListener("click", () => {
    burgerMenu.classList.toggle("is-active");
    navbarMenu.classList.toggle("is-active");

    if (navbarMenu.classList.contains("is-active")) {
      //   navbarMenu.style.height = 400+ "px";
      $("#menu").css("height", "calc(100vh - " + header + "px)");
      //  navbarMenu.style.maxHeight = navbarMenu.scrollHeight + "px";
    } else {
      navbarMenu.removeAttribute("style");
    }
  });
});

(function ($) {
  var paginate = {
    startPos: function (pageNumber, perPage) {
      // determine what array position to start from
      // based on current page and # per page
      return pageNumber * perPage;
    },

    getPage: function (items, startPos, perPage) {
      // declare an empty array to hold our page items
      var page = [];

      // only get items after the starting position
      items = items.slice(startPos, items.length);

      // loop remaining items until max per page
      for (var i = 0; i < perPage; i++) {
        page.push(items[i]);
      }

      return page;
    },

    totalPages: function (items, perPage) {
      // determine total number of pages
      return Math.ceil(items.length / perPage);
    },

    createBtns: function (totalPages, currentPage) {
      // create buttons to manipulate current page
      var pagination = $('<div class="pagination" />');

      // add a "first" button
      pagination.append(
        '<span class="pagination-button"><i class="far fa-angle-left"></i></span>'
      );

      // add pages inbetween
      for (var i = 1; i <= totalPages; i++) {
        // truncate list when too large
        if (totalPages > 5 && currentPage !== i) {
          // if on first two pages
          if (currentPage === 1 || currentPage === 2) {
            // show first 5 pages
            if (i > 5) continue;
            // if on last two pages
          } else if (
            currentPage === totalPages ||
            currentPage === totalPages - 1
          ) {
            // show last 5 pages
            if (i < totalPages - 4) continue;
            // otherwise show 5 pages w/ current in middle
          } else {
            if (i < currentPage - 2 || i > currentPage + 2) {
              continue;
            }
          }
        }

        // markup for page button
        var pageBtn = $('<span class="pagination-button page-num" />');

        // add active class for current page
        if (i == currentPage) {
          pageBtn.addClass("active");
        }

        // set text to the page number
        pageBtn.text(i);

        // add button to the container
        pagination.append(pageBtn);
      }

      // add a "last" button
      pagination.append(
        $(
          '<span class="pagination-button"><i class="far fa-angle-right"></i></span>'
        )
      );

      return pagination;
    },

    createPage: function (items, currentPage, perPage) {
      // remove pagination from the page
      $(".pagination").remove();

      // set context for the items
      var container = items.parent(),
        // detach items from the page and cast as array
        items = items.detach().toArray(),
        // get start position and select items for page
        startPos = this.startPos(currentPage - 1, perPage),
        page = this.getPage(items, startPos, perPage);

      // loop items and readd to page
      $.each(page, function () {
        // prevent empty items that return as Window
        if (this.window === undefined) {
          container.append($(this));
        }
      });

      // prep pagination buttons and add to page
      var totalPages = this.totalPages(items, perPage),
        pageButtons = this.createBtns(totalPages, currentPage);

      container.after(pageButtons);
    },
  };

  // stuff it all into a jQuery method!
  $.fn.paginate = function (perPage) {
    var items = $(this);

    // default perPage to 5
    if (isNaN(perPage) || perPage === undefined) {
      perPage = 5;
    }

    // don't fire if fewer items than perPage
    if (items.length <= perPage) {
      return true;
    }

    // ensure items stay in the same DOM position
    if (items.length !== items.parent()[0].children.length) {
      items.wrapAll('<div class="pagination-items" />');
    }

    // paginate the items starting at page 1
    paginate.createPage(items, 1, perPage);

    // handle click events on the buttons
    $(document).on("click", ".pagination-button", function (e) {
      // get current page from active button
      var currentPage = parseInt($(".pagination-button.active").text(), 10),
        newPage = currentPage,
        totalPages = paginate.totalPages(items, perPage),
        target = $(e.target);

      // get numbered page
      newPage = parseInt(target.text(), 10);
      if (target.text() == "«") newPage = 1;
      if (target.text() == "»") newPage = totalPages;

      // ensure newPage is in available range
      if (newPage > 0 && newPage <= totalPages) {
        paginate.createPage(items, newPage, perPage);
      }
    });
  };
})(jQuery);
$(".listing-page-content .list-item").paginate(12);
$(".details-page-list .list-item").paginate(4);
$(".video-page-content-box-section .list-item").paginate(6);

// Mapping between column names and Owl Carousel item indices
const itemIndices = {
  residential: 0,
  commercial: 1,
  baggage: 2,
};

// Function to handle click event on top columns
$(".owl_top").on("click", function () {
  const itemName = $(this).data("carousel-item"); // Get item name from data attribute
  const itemIndex = itemIndices[itemName]; // Get corresponding item index
  $("#Solution_owl").trigger("to.owl.carousel", itemIndex); // Trigger Owl Carousel to slide to the specified index

  $(".Residental_img").removeClass("active");

  $(this).find(".Residental_img").addClass("active");
});

function handleOwlChange(event) {
  const currentItemIndex = event.item.index; // Get class of current item

  $(".Residental_img").removeClass("active");

  let itemName;

  $?.each(itemIndices, function (name, index) {
    if (index === currentItemIndex) {
      itemName = name;
      return false; // Exit the loop once the item name is found
    }
  });

  if (itemName) {
    $(`.owl_top[data-carousel-item="${itemName}"] .Residental_img`).addClass(
      "active"
    );

    console.log(itemName);
  }
}



$(function () {
  $("#Solution_owl").owlCarousel({
    loop: true,
    margin: 20,
    nav: true,
    dots: true,
    items: 1,
    onChanged: handleOwlChange,
    navText: [
      "<img src='images/AskNavigator/left.svg' alt='' class='left_right'>",
      "<img src='images/AskNavigator/right.svg' alt='' class='left_right'>",
    ],
    responsive: {
      0: {
        items: 1,
      },
      600: {
        items: 1,
      },
      1000: {
        items: 1,
      },
    },
  });
});

$(function () {
  $(".case-studies-slider").owlCarousel({
    loop: true,
    margin: 50,
    dots: true,
    nav: false,
    autoplay: false,
    autoplayTimeout: 3000,
    responsive: {
      0: {
        items: 1,
      },
      600: {
        items: 1,
      },
      768: {
        items: 2,
      },

      992: {
        items: 2,
        autoplay: true,
      },
      1200: {
        items: 3,
      },
    },
  });
});
$(function () {
  $(".slide_Case").owlCarousel({
    loop: true,
    margin: 20,
    dots: true,
    nav: false,
    autoplay: false,
    autoplayTimeout: 3000,
    responsive: {
      0: {
        items: 1,
      },
      600: {
        items: 1,
      },
      768: {
        items: 2,
      },

      992: {
        items: 2,
        autoplay: true,
      },
      1200: {
        items: 2,
      },
    },
  });
});

$(function () {
  $(".Our_T_Partners_slider").owlCarousel({
    loop: true,
    margin: 35,
    dots: true,
    nav: false,
    autoplay: false,
    autoplayTimeout: 3000,
    responsive: {
      0: {
        items: 1,
      },
      600: {
        items: 1,
      },
      768: {
        items: 2,
      },

      992: {
        items: 2,
        autoplay: true,
      },
      1200: {
        items: 2,
      },
    },
  });
});

// form processoe

var $body = $("body");
var $progressBar = $("progress");
var $animContainer = $(".animation-container");
var value = 0;
var transitionEnd = "webkitTransitionEnd transitionend";

/**
 * Resets the form back to the default state.
 * ==========================================
 */
function formReset() {
  value = 0;
  $progressBar.val(value);
  $("form input").not("button").val("").removeClass("hasInput");
  $(".js-form-step").removeClass("left leaving");
  $(".js-form-step")
    .not('.js-form-step[data-step="1"]')
    .addClass("hidden waiting");
  $('.js-form-step[data-step="1"]').removeClass("hidden");
  $(".form-progress-indicator").not(".one").removeClass("active");

  $animContainer.css({
    paddingBottom: $('.js-form-step[data-step="1"]').height() + "px",
  });

  console.warn("Form reset.");
  return false;
}

/**
 * Sets up the click handlers on the form. Next/reset.
 * ===================================================
 */
function setupClickHandlers() {
  // Show next form on continue click
  $('button[type="submit"]').on("click", function (event) {
    event.preventDefault();
    var $currentForm = $(this).parents(".js-form-step");
    showNextForm($currentForm);
  });

  // Reset form on reset button click
  $(".js-reset").on("click", function () {
    formReset();
  });

  return false;
}

/**
 * Shows the next form.
 * @param - Node - The current form.
 * ======================================
 */

function showNextForm($currentForm) {
  var currentFormStep = parseInt($currentForm.attr("data-step")) || false;
  var $nextForm = $('.js-form-step[data-step="' + (currentFormStep + 1) + '"]');
  var isLastStep = $nextForm.length === 0;

  var $requiredInputs = $currentForm.find("input[required]");
  var isValid = true;

  $requiredInputs.each(function () {
    if (!$(this).val()) {
      $(this)
        .siblings(".error-message")
        .addClass("show")
        .css("display", "block");
      isValid = false;
    } else {
      $(this)
        .siblings(".error-message")
        .removeClass("show")
        .css("display", "none");
    }
  });

  if (!isValid) {
    return false;
  }

  $body.addClass("freeze");

  $("html, body").animate(
    {
      scrollTop: $progressBar.offset().top,
    },
    "fast"
  );

  $currentForm.addClass("leaving");
  $currentForm.addClass("hidden");

  $animContainer.css({
    paddingBottom: $nextForm.height() + "px",
  });

  $nextForm
    .removeClass("hidden")
    .addClass("coming")
    .one(transitionEnd, function () {
      $nextForm.removeClass("coming waiting");
    });

  if (isLastStep) {
    console.log("Redirecting to Congratulations.html...");
    window.location.href = "Congratulations.html";

    setTimeout(function () {
      console.log("3 seconds passed. Redirecting to Form.html...");
      window.history.replaceState({}, document.title, window.location.pathname);
      window.location.href = "Form.html";
    }, 3000);
  } else {
    value += 33;

    $(".form-progress")
      .find(".form-progress-indicator.active")
      .next(".form-progress-indicator")
      .addClass("active");

    $progressBar.val(value);
    $(".js-form-progress-completion").html($progressBar.val() + "% complete");
  }

  $body.removeClass("freeze");

  return false;
}

$(document).ready(function () {
  var $currentForm = $(".js-form-step:visible");
  var currentFormStep = parseInt($currentForm.attr("data-step")) || false;
  if (currentFormStep === 1) {
    $("#previousButton").prop("disabled", true);
  }

  $(document).on("click", "#previousButton", function () {
    var $currentForm = $(".js-form-step:visible");
    showPreviousForm($currentForm);
  });
});

function showPreviousForm($currentForm) {
  var currentFormStep = parseInt($currentForm.attr("data-step")) || false;
  var $previousForm = $(
    '.js-form-step[data-step="' + (currentFormStep - 1) + '"]'
  );

  $body.addClass("freeze");

  $("html, body").animate(
    {
      scrollTop: $progressBar.offset().top,
    },
    "fast"
  );

  $currentForm.addClass("leaving");
  $currentForm.addClass("hidden");

  $animContainer.css({
    paddingBottom: $previousForm.height() + "px",
  });

  $previousForm
    .removeClass("hidden")
    .addClass("coming")
    .one(transitionEnd, function () {
      $previousForm.removeClass("coming waiting");
    });

  value -= 33;

  if (value < 0) {
    value = 0;
  }

  $(".form-progress")
    .find(".form-progress-indicator.active")
    .removeClass("active")
    .prev(".form-progress-indicator")
    .addClass("active");

  $progressBar.val(value);
  $(".js-form-progress-completion").html($progressBar.val() + "% complete");

  $body.removeClass("freeze");
}

/**
 * Sets up and handles the float labels on the inputs.
 =====================================================
 */
function setupFloatLabels() {
  // Check the inputs to see if we should keep the label floating or not
  $("form input")
    .not("button")
    .on("blur", function () {
      // Different validation for different inputs
      switch (this.tagName) {
        case "SELECT":
          if (this.value > 0) {
            this.className = "hasInput";
          } else {
            this.className = "";
          }
          break;

        case "INPUT":
          if (this.value !== "") {
            this.className = "hasInput";
          } else {
            this.className = "";
          }
          break;

        default:
          break;
      }
    });

  return false;
}

/**
 * Gets the party started.
 * =======================
 */
function init() {
  formReset();
  setupFloatLabels();
  setupClickHandlers();
}

init();

// Function to handle item selection and update details input
function handleItemSelection(event, detailsInput) {
  if (event.target.tagName === "LI") {
    const selectedItem = event.target.textContent;
    if (
      selectedItem === "Today" ||
      selectedItem === "Tomorrow" ||
      selectedItem === "Day after Tomorrow"
    ) {
      const today = new Date();

      let offset = 0;
      if (selectedItem === "Tomorrow") {
        offset = 1;
      } else if (selectedItem === "Day after Tomorrow") {
        offset = 2;
      }

      const selectedDate = new Date(
        today.getTime() + offset * 24 * 60 * 60 * 1000
      );

      const formattedDate = selectedDate.toISOString().split("T")[0];

      detailsInput.value = formattedDate;
    } else {
      const dateParts = selectedItem.split("/");
      if (dateParts.length === 3) {
        const year = parseInt(dateParts[2]);
        const month = parseInt(dateParts[1]);
        const day = parseInt(dateParts[0]);

        if (!isNaN(year) && !isNaN(month) && !isNaN(day)) {
          const selectedDate = new Date(year, month, day);

          if (!isNaN(selectedDate.getTime())) {
            const formattedDate = selectedDate.toISOString().split("T")[0];

            detailsInput.value = formattedDate;
            return;
          }
        }
      }
      detailsInput.value = selectedItem;
    }
  }
}

// List 1
const itemList_a = document.getElementById("itemList_a");
const detailsInput_a = document.getElementById("lastName");
itemList_a.addEventListener("click", function (event) {
  handleItemSelection(event, detailsInput_a);
});

// List 2
const itemList_b = document.getElementById("itemList_b");
const detailsInput_b = document.getElementById("relocation_to");
itemList_b.addEventListener("click", function (event) {
  handleItemSelection(event, detailsInput_b);
});

// List 3
const itemList_c = document.getElementById("itemList_c");
const detailsInput_c = document.getElementById("date_relocation");
itemList_c.addEventListener("click", function (event) {
  handleItemSelection(event, detailsInput_c);
});

// List 4
const itemList_d = document.getElementById("itemList_d");
const detailsInput_d = document.getElementById("items_name");
itemList_d.addEventListener("click", function (event) {
  handleItemSelection(event, detailsInput_d);
});




function validateForms() {
  var names = document.getElementById("ynames").value;
  var emails = document.getElementById("yemails").value;
  var isValid = true;

  // Clear previous error messages
  document.getElementById("nameErrors").innerText = "";
  document.getElementById("emailErrors").innerText = "";

  // Validate name
  if (names.trim() === "") {
    document.getElementById("nameErrors").innerText = "Please enter your name";
    isValid = false;
  }

  // Validate email
  if (emails.trim() === "") {
    document.getElementById("emailErrors").innerText = "Please enter your email";
    isValid = false;
  }

  // If form is valid, submit it
  if (isValid) {
    document.getElementById("complaintForms").submit();
  }
}



function validateForm() {
  var name = document.getElementById("yname").value;
  var mobile = document.getElementById("mobile").value;
  var issue = document.getElementById("cars").value;
  var concern = document.getElementById("concern").value;
  var isValid = true;

  // Clear previous error messages
  document.getElementById("nameError").innerText = "";
  document.getElementById("mobileError").innerText = "";
  document.getElementById("issueError").innerText = "";
  document.getElementById("concernError").innerText = "";

  // Validate name
  if (name.trim() === "") {
    document.getElementById("nameError").innerText = "Please enter your name";
    isValid = false;
  }

  // Validate mobile
  if (mobile.trim() === "") {
    document.getElementById("mobileError").innerText =
      "Please enter your mobile number";
    isValid = false;
  }

  // Validate issue selection
  if (issue === "") {
    document.getElementById("issueError").innerText =
      "Please select your Delay issue";
    isValid = false;
  }

  // Validate if concern is empty
  if (concern.trim() === "") {
    document.getElementById("concernError").innerText =
      "Please enter your concern";
    isValid = false;
  } else {
    var words = concern
      .trim()
      .split(/\s+/)
      .filter(function (word) {
        return word.length > 0;
      });
    console.log("Number of words:", words.length);
    if (words.length > 10) {
      document.getElementById("concernError").innerText =
        "Please enter maximum 10 words for your concern";
      isValid = false;
    }
  }

  // If form is valid, submit it
  if (isValid) {
    document.getElementById("complaintForm").submit();
  }
}
